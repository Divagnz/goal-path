"""
GoalPath FastAPI Application
Enhanced main application with HTMX frontend support
"""

from fastapi import FastAPI, Request, Depends, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from sqlalchemy import func
import uvicorn
from pathlib import Path
from datetime import datetime, date

from .database import get_db, init_database
from .models import Project, Task, Goal, GoalProject
from .routers import projects_router, tasks_router, goals_router
from .routers.htmx_projects import router as htmx_projects_router
from .routers.htmx_tasks import router as htmx_tasks_router

# Create FastAPI application
app = FastAPI(
    title="GoalPath",
    description="Enhanced Project Management System with FastAPI and HTMX",
    version="0.2.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Setup static files and templates
static_dir = Path(__file__).parent / "static"
templates_dir = Path(__file__).parent / "templates"

# Create directories if they don't exist
static_dir.mkdir(exist_ok=True)
templates_dir.mkdir(exist_ok=True)

app.mount("/static", StaticFiles(directory=static_dir), name="static")
templates = Jinja2Templates(directory=templates_dir)

# Include API routers
app.include_router(projects_router)
app.include_router(tasks_router)
app.include_router(goals_router)

# Include HTMX routers
app.include_router(htmx_projects_router)
app.include_router(htmx_tasks_router)

# CORS middleware for development
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure properly for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    """Initialize database on startup"""
    try:
        init_database()
        print("✅ Database initialized successfully")
    except Exception as e:
        print(f"❌ Database initialization failed: {e}")

# Helper function to detect HTMX requests
def is_htmx_request(request: Request) -> bool:
    """Check if request is from HTMX"""
    return request.headers.get("HX-Request") == "true"

# Root route - Enhanced Dashboard
@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    """Enhanced dashboard view with real-time stats"""
    
    # Get dashboard data
    projects = db.query(Project).order_by(Project.updated_at.desc()).limit(10).all()
    recent_tasks = db.query(Task).order_by(Task.updated_at.desc()).limit(15).all()
    active_goals = db.query(Goal).filter(Goal.status == "active").limit(6).all()
    
    # Calculate enhanced statistics
    total_projects = db.query(Project).count()
    total_tasks = db.query(Task).count()
    completed_tasks = db.query(Task).filter(Task.status == "done").count()
    
    # Calculate this week's completed tasks
    from datetime import timedelta
    week_start = date.today() - timedelta(days=date.today().weekday())
    tasks_completed_this_week = db.query(Task).filter(
        Task.status == "done",
        func.date(Task.updated_at) >= week_start
    ).count()
    
    # Get today's tasks (tasks due today or overdue)
    today = date.today()
    todays_tasks = db.query(Task).filter(
        Task.due_date <= today,
        Task.status.in_(["todo", "in_progress"])
    ).limit(5).all()
    
    context = {
        "request": request,
        "projects": projects,
        "recent_tasks": recent_tasks,
        "active_goals": active_goals,
        "todays_tasks": todays_tasks,
        "stats": {
            "total_projects": total_projects,
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "completion_rate": round((completed_tasks / total_tasks * 100) if total_tasks > 0 else 0, 1),
            "tasks_completed_this_week": tasks_completed_this_week
        }
    }
    
    # Return content fragment for HTMX requests, full page otherwise
    if is_htmx_request(request):
        return templates.TemplateResponse("fragments/dashboard_content.html", context)
    else:
        return templates.TemplateResponse("dashboard.html", context)

# Modal Routes for HTMX
@app.get("/modals/create-project", response_class=HTMLResponse)
async def create_project_modal(request: Request, db: Session = Depends(get_db)):
    """Create project modal"""
    context = {"request": request}
    return templates.TemplateResponse("modals/create_project.html", context)

@app.get("/modals/create-task", response_class=HTMLResponse)
async def create_task_modal(request: Request, db: Session = Depends(get_db)):
    """Create task modal"""
    projects = db.query(Project).filter(Project.status == "active").all()
    context = {"request": request, "projects": projects}
    return templates.TemplateResponse("modals/create_task.html", context)

@app.get("/modals/create-goal", response_class=HTMLResponse)
async def create_goal_modal(request: Request, db: Session = Depends(get_db)):
    """Create goal modal"""
    projects = db.query(Project).filter(Project.status == "active").all()
    goals = db.query(Goal).filter(Goal.status == "active").all()
    context = {"request": request, "projects": projects, "goals": goals}
    return templates.TemplateResponse("modals/create_goal.html", context)

@app.get("/modals/edit-task/{task_id}", response_class=HTMLResponse)
async def edit_task_modal(task_id: str, request: Request, db: Session = Depends(get_db)):
    """Edit task modal"""
    task = db.query(Task).filter(Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    projects = db.query(Project).filter(Project.status == "active").all()
    context = {"request": request, "task": task, "projects": projects}
    return templates.TemplateResponse("modals/edit_task.html", context)

# Enhanced API endpoints for dashboard
@app.get("/api/dashboard/stats")
async def get_dashboard_stats(request: Request, db: Session = Depends(get_db)):
    """Get real-time dashboard statistics"""
    
    # Calculate current stats
    total_projects = db.query(Project).count()
    total_tasks = db.query(Task).count()
    completed_tasks = db.query(Task).filter(Task.status == "done").count()
    
    # Calculate this week's stats
    from datetime import timedelta
    week_start = date.today() - timedelta(days=date.today().weekday())
    tasks_completed_this_week = db.query(Task).filter(
        Task.status == "done",
        func.date(Task.updated_at) >= week_start
    ).count()
    
    # Get active goals for progress calculation
    active_goals = db.query(Goal).filter(Goal.status == "active").all()
    
    context = {
        "request": request,
        "active_goals": active_goals,
        "stats": {
            "total_projects": total_projects,
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "completion_rate": round((completed_tasks / total_tasks * 100) if total_tasks > 0 else 0, 1),
            "tasks_completed_this_week": tasks_completed_this_week
        }
    }
    
    # Return HTML fragment for HTMX requests, JSON for API calls
    if is_htmx_request(request):
        return templates.TemplateResponse("fragments/dashboard_stats.html", context)
    else:
        return {
            "total_projects": total_projects,
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "completion_rate": round((completed_tasks / total_tasks * 100) if total_tasks > 0 else 0, 1),
            "tasks_completed_this_week": tasks_completed_this_week,
            "updated_at": datetime.now().isoformat()
        }

# Projects page
@app.get("/projects", response_class=HTMLResponse)
async def projects_page(request: Request, db: Session = Depends(get_db)):
    """Projects management page"""
    projects = db.query(Project).order_by(Project.updated_at.desc()).all()
    
    # Calculate statistics for each project
    for project in projects:
        total_tasks = db.query(Task).filter(Task.project_id == project.id).count()
        completed_tasks = db.query(Task).filter(
            Task.project_id == project.id,
            Task.status == "done"
        ).count()
        project.total_tasks = total_tasks
        project.completed_tasks = completed_tasks
        project.completion_percentage = (
            (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0.0
        )
    
    context = {"request": request, "projects": projects}
    
    # Return content fragment for HTMX requests, full page otherwise
    if is_htmx_request(request):
        return templates.TemplateResponse("fragments/projects_content.html", context)
    else:
        # For now, return fragment since we don't have full projects.html template
        return templates.TemplateResponse("fragments/projects_content.html", context)

# Tasks page
@app.get("/tasks", response_class=HTMLResponse)
async def tasks_page(request: Request, db: Session = Depends(get_db)):
    """Tasks management page"""
    tasks = db.query(Task).order_by(Task.updated_at.desc()).all()
    projects = db.query(Project).all()
    
    context = {"request": request, "tasks": tasks, "projects": projects}
    
    # Return content fragment for HTMX requests, full page otherwise
    if is_htmx_request(request):
        return templates.TemplateResponse("fragments/tasks_content.html", context)
    else:
        # For now, return fragment since we don't have full tasks.html template
        return templates.TemplateResponse("fragments/tasks_content.html", context)

# Goals page
@app.get("/goals", response_class=HTMLResponse)
async def goals_page(request: Request, db: Session = Depends(get_db)):
    """Goals management page"""
    goals = db.query(Goal).order_by(Goal.updated_at.desc()).all()
    
    # Calculate progress for each goal
    for goal in goals:
        project_links = db.query(GoalProject).filter(GoalProject.goal_id == goal.id).all()
        if project_links:
            total_weight = sum(float(link.weight) for link in project_links)
            weighted_progress = 0.0
            for link in project_links:
                # Calculate project completion
                total_tasks = db.query(Task).filter(Task.project_id == link.project_id).count()
                completed_tasks = db.query(Task).filter(
                    Task.project_id == link.project_id,
                    Task.status == "done"
                ).count()
                project_progress = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0.0
                weighted_progress += project_progress * float(link.weight)
            
            goal.calculated_progress = weighted_progress / total_weight if total_weight > 0 else 0.0
        else:
            goal.calculated_progress = float(goal.progress_percentage)
        
        goal.linked_projects = len(project_links)
    
    context = {"request": request, "goals": goals}
    
    # Return content fragment for HTMX requests, full page otherwise
    if is_htmx_request(request):
        return templates.TemplateResponse("fragments/goals_content.html", context)
    else:
        # For now, return fragment since we don't have full goals.html template
        return templates.TemplateResponse("fragments/goals_content.html", context)

# Analytics page
@app.get("/analytics", response_class=HTMLResponse)
async def analytics_page(request: Request, db: Session = Depends(get_db)):
    """Analytics and reporting page"""
    # Get analytics data
    projects = db.query(Project).all()
    tasks = db.query(Task).all()
    goals = db.query(Goal).all()
    
    # Calculate analytics
    project_status_counts = {}
    task_status_counts = {}
    task_priority_counts = {}
    
    for project in projects:
        status = project.status
        project_status_counts[status] = project_status_counts.get(status, 0) + 1
    
    for task in tasks:
        status = task.status
        priority = task.priority
        task_status_counts[status] = task_status_counts.get(status, 0) + 1
        task_priority_counts[priority] = task_priority_counts.get(priority, 0) + 1
    
    context = {
        "request": request,
        "analytics": {
            "project_status_counts": project_status_counts,
            "task_status_counts": task_status_counts,
            "task_priority_counts": task_priority_counts,
            "total_projects": len(projects),
            "total_tasks": len(tasks),
            "total_goals": len(goals)
        }
    }
    
    # Return content fragment for HTMX requests, full page otherwise
    if is_htmx_request(request):
        return templates.TemplateResponse("fragments/analytics_content.html", context)
    else:
        # For now, return fragment since we don't have full analytics.html template
        return templates.TemplateResponse("fragments/analytics_content.html", context)

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "app": "goalpath", "version": "0.2.0"}

# Quick task endpoint for dashboard
@app.post("/api/quick-task")
async def create_quick_task(request: Request, db: Session = Depends(get_db)):
    """Create a quick task from dashboard"""
    form_data = await request.form()
    
    task_data = {
        "title": form_data.get("title"),
        "priority": form_data.get("priority", "medium"),
        "project_id": form_data.get("project_id") if form_data.get("project_id") else None,
        "task_type": "task",
        "status": "todo",
        "created_by": "system"
    }
    
    # Remove None values
    task_data = {k: v for k, v in task_data.items() if v is not None}
    
    new_task = Task(**task_data)
    db.add(new_task)
    db.commit()
    db.refresh(new_task)
    
    return {"message": "Task created successfully", "task_id": new_task.id}

def main():
    """Main entry point for production"""
    uvicorn.run(
        "goalpath.main:app",
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )

def dev():
    """Development entry point with auto-reload"""
    uvicorn.run(
        "goalpath.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="debug"
    )

if __name__ == "__main__":
    dev()
