"""
GoalPath - Project Management System
"""

__version__ = "0.1.0"
__author__ = "GoalPath Team"
__description__ = "Project Management System with FastAPI and HTMX"
